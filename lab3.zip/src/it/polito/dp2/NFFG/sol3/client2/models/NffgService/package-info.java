@javax.xml.bind.annotation.XmlSchema(namespace = "https://france193.wordpress.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.polito.dp2.NFFG.sol3.client2.models.NffgService;
